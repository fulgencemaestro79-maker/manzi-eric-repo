# RWANDA HISTORY

A multilingual Rwanda history learning website with a grounded AI history assistant.

## Requirements
- Node.js 18 or newer
- npm
- Optional: an OpenAI API key for full AI chat

## Run locally
1. Open this folder in VS Code.
2. Open the VS Code terminal.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`.
   - Windows PowerShell: `Copy-Item .env.example .env`
   - Command Prompt: `copy .env.example .env`
5. Open `.env` and add your API key to `OPENAI_API_KEY`.
   - Without an API key, the site still runs and the assistant uses its built-in historical knowledge cards. It will clearly say when a question is outside its local knowledge.
6. Start the app:

   ```bash
   npm start
   ```

7. Open http://localhost:3000

## Features
- Kinyarwanda, English and French interface
- Rwanda history topic library and timeline
- Searchable history cards
- AI chat grounded in a local reference collection
- Local fallback answers when no API key is configured
- Quiz with explanations
- Responsive layout for mobile and desktop

## AI and historical accuracy
The AI endpoint is configured to answer only about Rwanda history and to distinguish documented facts from uncertainty. The included knowledge collection is an introductory set, not a complete archive. For school, academic, legal or memorial use, verify claims against the cited primary and institutional sources.

## Important
- Never put your API key in frontend files.
- The server stores chat history locally in `data/chats.json`.
- Do not use this starter app as a substitute for archival research or testimony.
