require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "history.json");
const CHAT_FILE = path.join(__dirname, "data", "chats.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const history = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));

function readChats() {
  try { return JSON.parse(fs.readFileSync(CHAT_FILE, "utf8")); }
  catch { return []; }
}
function saveChat(entry) {
  const chats = readChats();
  chats.push(entry);
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chats.slice(-500), null, 2));
}
function normalize(s) {
  return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function findLocalAnswer(question, lang) {
  const q = normalize(question);
  const words = q.split(/[^a-z0-9]+/).filter(w => w.length > 2);
  const scored = history.topics.map(topic => {
    const haystack = normalize([
      topic.year, ...Object.values(topic.title), ...Object.values(topic.summary),
      ...Object.values(topic.detail), ...topic.tags
    ].join(" "));
    const score = words.reduce((n, word) => n + (haystack.includes(word) ? 1 : 0), 0);
    return { topic, score };
  }).sort((a,b) => b.score - a.score);
  if (!scored.length || scored[0].score === 0) return null;
  const t = scored[0].topic;
  const title = t.title[lang] || t.title.en;
  const detail = t.detail[lang] || t.detail.en;
  return {
    answer: `**${title} (${t.year})**\n\n${detail}\n\n*This is an introductory summary. Consult the references below for deeper research.*`,
    sources: history.sources.slice(0, 4),
    mode: "local"
  };
}

const SYSTEM_PROMPT = `You are RWANDA HISTORY AI, a careful educational assistant specializing in the history of Rwanda.
Answer in the user's requested language: Kinyarwanda (rw), English (en), or French (fr).
Stay focused on Rwanda's history. If the user asks unrelated questions, politely explain your scope.
Use the supplied reference notes as grounding. Do not invent dates, quotations, casualty figures, names, or sources.
Distinguish established facts, interpretations, and contested historical debates. Be respectful and survivor-centred when discussing the 1994 Genocide against the Tutsi.
Use the correct term "Genocide against the Tutsi" / "Jenoside yakorewe Abatutsi" / "génocide perpétré contre les Tutsi".
Do not present the genocide as a spontaneous or symmetrical conflict. Explain that it was an organized genocide targeting Tutsi; also acknowledge that Hutu opponents of the genocide were murdered.
If the notes do not support an answer, say what is unknown and suggest reliable institutions or archives. Never fabricate citations.
Structure answers clearly with short paragraphs and dates when relevant.`;

app.get("/api/history", (_req, res) => {
  res.json({ topics: history.topics, sources: history.sources, quiz: history.quiz });
});

app.post("/api/chat", async (req, res) => {
  const { message, language = "en", sessionId = "guest" } = req.body || {};
  const lang = ["rw", "en", "fr"].includes(language) ? language : "en";
  if (!message || typeof message !== "string" || message.trim().length < 2) {
    return res.status(400).json({ error: "Please enter a question." });
  }
  if (message.length > 2000) return res.status(400).json({ error: "Question is too long (maximum 2,000 characters)." });

  const notes = history.topics.map(t =>
    `${t.year} | ${t.title.en}\n${t.detail.en}\nRW: ${t.detail.rw}\nFR: ${t.detail.fr}`
  ).join("\n\n");
  const local = findLocalAnswer(message, lang);

  if (!process.env.OPENAI_API_KEY) {
    if (local) {
      saveChat({ sessionId, language: lang, question: message, answer: local.answer, createdAt: new Date().toISOString(), mode: "local" });
      return res.json(local);
    }
    const noKey = {
      rw: "Nta makuru ahagije mfite muri iyi verisiyo yo gusubiza icyo kibazo neza. Gerageza kubaza ku bwami, ubukoloni, ubwigenge, Jenoside yakorewe Abatutsi cyangwa u Rwanda nyuma ya 1994. Ushobora no gukoresha amasoko ari ku rubuga.",
      en: "I don't have enough information in this starter version to answer that accurately. Try asking about the kingdom, colonial period, independence, the Genocide against the Tutsi, or Rwanda after 1994. You can also consult the sources listed on this site.",
      fr: "Cette version de démarrage ne contient pas assez d'informations pour répondre avec précision. Essayez une question sur le royaume, la période coloniale, l'indépendance, le génocide perpétré contre les Tutsi ou le Rwanda après 1994. Consultez également les sources indiquées sur le site."
    };
    return res.json({ answer: noKey[lang], sources: history.sources, mode: "local" });
  }

  try {
    const base = (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
    const response = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        temperature: 0.2,
        messages: [
          { role: "system", content: SYSTEM_PROMPT + "\n\nREFERENCE NOTES:\n" + notes },
          { role: "user", content: `Language: ${lang}\nQuestion: ${message}` }
        ]
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || "AI provider request failed");
    const answer = data.choices?.[0]?.message?.content;
    if (!answer) throw new Error("The AI returned an empty response.");
    const result = { answer, sources: history.sources, mode: "ai" };
    saveChat({ sessionId, language: lang, question: message, answer, createdAt: new Date().toISOString(), mode: "ai" });
    res.json(result);
  } catch (error) {
    console.error("AI error:", error.message);
    if (local) return res.json({ ...local, warning: "AI service unavailable; showing a local reference summary." });
    res.status(502).json({ error: "The AI service could not answer right now. Check your API key and connection, then try again." });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => {
  console.log(`RWANDA HISTORY is running at http://localhost:${PORT}`);
});
