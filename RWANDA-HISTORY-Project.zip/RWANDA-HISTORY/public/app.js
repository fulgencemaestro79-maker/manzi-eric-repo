const translations = {
  en: {
    navExplore:"Explore",navTimeline:"Timeline",navAI:"History AI",navSources:"Sources",askAI:"Ask AI",
    eyebrow:"A living journey through our past",heroTitle:"Understand our past.<br><em>Shape our future.</em>",
    heroDesc:"Explore the history of Rwanda — from the kingdom and colonial era to the 1994 Genocide against the Tutsi and the journey of rebuilding.",
    exploreHistory:"Explore history",talkToAI:"Talk to History AI",heroMeta:"A learning space for every generation",
    heroCaptionSmall:"THE LAND OF A THOUSAND HILLS",heroCaption:"One history. Many voices.",languages:"Languages",scrollExplore:"SCROLL TO EXPLORE ↓",
    discoverEyebrow:"DISCOVER RWANDA",exploreTitle:"Explore our <em>history</em>",exploreSub:"Follow the chapters that shaped Rwanda. Each topic offers an introduction and a path to deeper learning.",
    searchPlaceholder:"Search Rwanda's history...",timelineEyebrow:"A JOURNEY THROUGH TIME",timelineTitle:"History at a <em>glance</em>",
    timelineSub:"A simplified timeline of important periods and milestones. Select a chapter above to read more.",
    aiEyebrow:"YOUR HISTORY COMPANION",aiTitle:"Curious about our past?<br><em>Ask History AI.</em>",
    aiDesc:"Ask questions about Rwanda's history in Kinyarwanda, English or French. Get clear explanations and references to continue learning.",
    aiTrust:"Grounded in historical reference notes · Respectful · Multilingual",suggest1:"What changed during colonial rule?",suggest2:"Explain the context of 1994",suggest3:"How did Rwanda rebuild?",
    assistantOnline:"Your history learning assistant",welcomeAI:"Muraho! I can help you explore Rwanda's history. What would you like to understand today?",
    tryAsking:"TRY ASKING",chatPlaceholder:"Ask a question about Rwanda's history...",chatFootnote:"AI can make mistakes. Check the references for important research.",
    quizEyebrow:"LEARN AS YOU GO",quizTitle:"Test your <em>knowledge</em>",quizSub:"A few short questions to help you remember key historical milestones.",
    sourcesEyebrow:"GO DEEPER",sourcesTitle:"History needs <em>good sources.</em>",sourcesSub:"Use institutional archives and research to verify details, explore testimonies and learn beyond this introduction.",
    sourceNote:"This website is an educational starting point, not a complete historical archive. Historical interpretation should be supported by evidence and multiple credible sources.",
    footerText:"Remembering with dignity. Learning with curiosity. Building with hope.",readChapter:"READ CHAPTER",askAboutTopic:"Ask AI about this topic ↗",question:"Question",next:"Next question",finish:"Finish quiz",correct:"Correct. ",incorrect:"Not quite. ",quizDone:"You completed the quiz!",score:"Your score",searchResults:"chapters found"
  },
  rw: {
    navExplore:"Ibyiciro",navTimeline:"Ibihe",navAI:"AI y'Amateka",navSources:"Amasoko",askAI:"Baza AI",
    eyebrow:"Urugendo rwo kumenya amateka yacu",heroTitle:"Menya amateka yacu.<br><em>Twubake ejo hazaza.</em>",
    heroDesc:"Sobanukirwa n'amateka y'u Rwanda — kuva ku bwami n'ubukoloni kugeza kuri Jenoside yakorewe Abatutsi mu 1994 no kongera kubaka igihugu.",
    exploreHistory:"Soma amateka",talkToAI:"Ganira na AI y'Amateka",heroMeta:"Ahantu ho kwigira h'ibisekuru byose",
    heroCaptionSmall:"IGIHUGU CY'IMISOZI IGIHUMBI",heroCaption:"Amateka amwe, amajwi menshi.",languages:"Indimi",scrollExplore:"MANUKA UREBE ↓",
    discoverEyebrow:"MENYA U RWANDA",exploreTitle:"Sobanukirwa n'<em>amateka yacu</em>",exploreSub:"Kurikirana ibice by'ingenzi byagize uruhare mu mateka y'u Rwanda. Buri gice kigufasha gutangira ubushakashatsi.",
    searchPlaceholder:"Shakisha mu mateka y'u Rwanda...",timelineEyebrow:"URUGENDO MU BIHE",timelineTitle:"Amateka mu <em>ncamake</em>",
    timelineSub:"Ibi ni ibihe by'ingenzi mu ncamake. Hitamo igice kiri hejuru kugira ngo usome birambuye.",
    aiEyebrow:"UMUFASHA WAWE MU MATEKA",aiTitle:"Ufite amatsiko ku mateka?<br><em>Baza AI y'Amateka.</em>",
    aiDesc:"Baza ibibazo ku mateka y'u Rwanda mu Kinyarwanda, English cyangwa Français. Uhabwe ibisobanuro n'amasoko wakomeza kwifashisha.",
    aiTrust:"Ishingiye ku nyandiko z'amateka · Yubaha abantu · Indimi nyinshi",suggest1:"Ni iki cyahindutse mu bukoloni?",suggest2:"Sobanura ibihe bya 1994",suggest3:"U Rwanda rwiyubatse rute?",
    assistantOnline:"Umufasha wawe mu kwiga amateka",welcomeAI:"Muraho! Ndi hano kugira ngo ngufashe kumenya amateka y'u Rwanda. Ni iki wifuza kumenya uyu munsi?",
    tryAsking:"GERAGEZA KUBAZA",chatPlaceholder:"Baza ikibazo ku mateka y'u Rwanda...",chatFootnote:"AI ishobora kwibeshya. Reba amasoko yizewe ku bushakashatsi bw'ingenzi.",
    quizEyebrow:"IGA UNASUBIRAMO",quizTitle:"Gerageza <em>ubumenyi bwawe</em>",quizSub:"Ibibazo bike bigufasha kwibuka amatariki n'ibikorwa by'ingenzi.",
    sourcesEyebrow:"KOMEZA UBUSHAKASHATSI",sourcesTitle:"Amateka akeneye <em>amasoko yizewe.</em>",sourcesSub:"Koresha ububiko bw'inyandiko n'ubushakashatsi bw'inzego zizewe kugira ngo wemeze amakuru.",
    sourceNote:"Uru rubuga ni intangiriro yo kwiga, si ububiko bwuzuye bw'amateka. Ibisobanuro by'amateka bigomba gushingira ku bimenyetso no ku masoko menshi yizewe.",
    footerText:"Kwibuka mu cyubahiro. Kwiga dufite amatsiko. Kubaka dufite icyizere.",readChapter:"SOMA IKI GICE",askAboutTopic:"Baza AI kuri iki gice ↗",question:"Ikibazo",next:"Ikibazo gikurikira",finish:"Soza ibibazo",correct:"Ni byo. ",incorrect:"Si byo neza. ",quizDone:"Usoje ibibazo!",score:"Amanota yawe",searchResults:"ibice byabonetse"
  },
  fr: {
    navExplore:"Explorer",navTimeline:"Chronologie",navAI:"IA Histoire",navSources:"Sources",askAI:"Demander à l'IA",
    eyebrow:"Un voyage vivant à travers notre passé",heroTitle:"Comprendre notre passé.<br><em>Construire notre avenir.</em>",
    heroDesc:"Explorez l'histoire du Rwanda — du royaume et de la période coloniale au génocide perpétré contre les Tutsi en 1994 et à la reconstruction.",
    exploreHistory:"Explorer l'histoire",talkToAI:"Parler à l'IA Histoire",heroMeta:"Un espace d'apprentissage pour chaque génération",
    heroCaptionSmall:"LE PAYS DES MILLE COLLINES",heroCaption:"Une histoire. Plusieurs voix.",languages:"Langues",scrollExplore:"DÉFILER POUR EXPLORER ↓",
    discoverEyebrow:"DÉCOUVRIR LE RWANDA",exploreTitle:"Explorer notre <em>histoire</em>",exploreSub:"Découvrez les chapitres qui ont façonné le Rwanda. Chaque thème offre une introduction et des pistes d'approfondissement.",
    searchPlaceholder:"Rechercher dans l'histoire du Rwanda...",timelineEyebrow:"UN VOYAGE DANS LE TEMPS",timelineTitle:"L'histoire en <em>bref</em>",
    timelineSub:"Une chronologie simplifiée des périodes et événements importants. Sélectionnez un chapitre pour en savoir plus.",
    aiEyebrow:"VOTRE COMPAGNON D'HISTOIRE",aiTitle:"Curieux de notre passé ?<br><em>Demandez à l'IA Histoire.</em>",
    aiDesc:"Posez des questions sur l'histoire du Rwanda en kinyarwanda, anglais ou français. Obtenez des explications claires et des références.",
    aiTrust:"Fondée sur des références historiques · Respectueuse · Multilingue",suggest1:"Qu'est-ce qui a changé sous la colonisation ?",suggest2:"Expliquer le contexte de 1994",suggest3:"Comment le Rwanda s'est-il reconstruit ?",
    assistantOnline:"Votre assistant d'apprentissage historique",welcomeAI:"Muraho ! Je peux vous aider à explorer l'histoire du Rwanda. Que souhaitez-vous comprendre aujourd'hui ?",
    tryAsking:"ESSAYEZ DE DEMANDER",chatPlaceholder:"Posez une question sur l'histoire du Rwanda...",chatFootnote:"L'IA peut se tromper. Vérifiez les références pour vos recherches importantes.",
    quizEyebrow:"APPRENDRE EN AVANÇANT",quizTitle:"Testez vos <em>connaissances</em>",quizSub:"Quelques questions pour mémoriser les grandes étapes historiques.",
    sourcesEyebrow:"APPROFONDIR",sourcesTitle:"L'histoire a besoin de <em>bonnes sources.</em>",sourcesSub:"Consultez les archives institutionnelles et les recherches pour vérifier les faits et découvrir les témoignages.",
    sourceNote:"Ce site est une introduction pédagogique, pas une archive historique exhaustive. Les interprétations historiques doivent s'appuyer sur des preuves et plusieurs sources crédibles.",
    footerText:"Se souvenir avec dignité. Apprendre avec curiosité. Construire avec espoir.",readChapter:"LIRE LE CHAPITRE",askAboutTopic:"Demander à l'IA sur ce sujet ↗",question:"Question",next:"Question suivante",finish:"Terminer le quiz",correct:"Correct. ",incorrect:"Pas tout à fait. ",quizDone:"Vous avez terminé le quiz !",score:"Votre score",searchResults:"chapitres trouvés"
  }
};

let lang = "en";
let topics = [], quiz = [], sources = [], quizIndex = 0, quizScore = 0, quizAnswered = false, currentTopic = null;
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const textFor = obj => obj?.[lang] || obj?.en || "";

function applyLanguage() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (translations[lang][key]) el.innerHTML = translations[lang][key];
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    if (translations[lang][key]) el.placeholder = translations[lang][key];
  });
  renderTopics($("#searchInput").value);
  renderTimeline();
  renderQuiz();
  renderSources();
}
function renderTopics(filter = "") {
  const q = filter.toLocaleLowerCase();
  const filtered = topics.filter(t => [textFor(t.title), textFor(t.summary), t.year, ...t.tags].join(" ").toLocaleLowerCase().includes(q));
  $("#resultCount").textContent = `${filtered.length} ${translations[lang].searchResults}`;
  $("#topicGrid").innerHTML = filtered.length ? filtered.map((t,i) => `
    <article class="topic-card" data-topic="${esc(t.id)}" tabindex="0" role="button" aria-label="${esc(textFor(t.title))}">
      <div class="topic-number"><span>CHAPTER 0${i+1}</span><span>↗</span></div>
      <h3>${esc(textFor(t.title))}</h3><p>${esc(textFor(t.summary))}</p>
      <div class="card-tags">${t.tags.slice(0,3).map(tag=>`<span>${esc(tag)}</span>`).join("")}</div>
      <div class="card-bottom"><span>${esc(t.year)}</span><span>${translations[lang].readChapter} →</span></div>
    </article>`).join("") : `<div class="loading-card">No matching chapters found.</div>`;
  document.querySelectorAll("[data-topic]").forEach(card => {
    const open = () => showTopic(card.dataset.topic);
    card.addEventListener("click", open);
    card.addEventListener("keydown", e => { if(e.key==="Enter"||e.key===" "){e.preventDefault();open();} });
  });
}
function renderTimeline() {
  $("#timelineTrack").innerHTML = topics.map(t => `<div class="timeline-item"><small>${esc(t.year)}</small><h3>${esc(textFor(t.title))}</h3><p>${esc(textFor(t.summary)).slice(0,115)}${textFor(t.summary).length>115?"…":""}</p></div>`).join("");
}
function renderSources() {
  $("#sourceGrid").innerHTML = sources.map((s,i)=>`<a class="source-card" href="${esc(s.url)}" target="_blank" rel="noopener noreferrer"><span class="source-icon">${["↗","▤","⌂","✦","◈","◎"][i%6]}</span><div><b>${esc(s.name)}</b><span>${new URL(s.url).hostname}</span></div></a>`).join("");
}
function showTopic(id) {
  currentTopic = topics.find(t=>t.id===id);
  if(!currentTopic)return;
  $("#modalYear").textContent = currentTopic.year;
  $("#modalTitle").textContent = textFor(currentTopic.title);
  $("#modalSummary").textContent = textFor(currentTopic.summary);
  $("#modalDetail").textContent = textFor(currentTopic.detail);
  $("#topicModal").classList.add("open");
  $("#topicModal").setAttribute("aria-hidden","false");
}
function closeModal() {
  $("#topicModal").classList.remove("open");
  $("#topicModal").setAttribute("aria-hidden","true");
}
function addMessage(content, role="assistant", isHtml=false) {
  const row = document.createElement("div");
  row.className = `message ${role==="user"?"user-message":"assistant-message"}`;
  const avatar = role==="user" ? "" : `<div class="message-avatar">✦</div>`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (isHtml) bubble.innerHTML = content;
  else bubble.textContent = content;
  row.innerHTML = avatar;
  row.appendChild(bubble);
  $("#chatMessages").appendChild(row);
  $("#chatMessages").scrollTop = $("#chatMessages").scrollHeight;
  return row;
}
function basicMarkdown(s) {
  return esc(s).replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br>");
}
async function sendChat(message) {
  const q = (message || $("#chatInput").value).trim();
  if (!q) return;
  addMessage(q,"user");
  $("#chatInput").value = "";
  $("#sendButton").disabled = true;
  const waiting = addMessage(lang==="rw"?"Ndimo gushaka igisubizo...":lang==="fr"?"Je prépare une réponse...":"Thinking…");
  try {
    const response = await fetch("/api/chat", {
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:q,language:lang,sessionId:"browser-session"})
    });
    const data = await response.json();
    waiting.remove();
    if (!response.ok) throw new Error(data.error || "Request failed");
    let html = basicMarkdown(data.answer || "");
    if (data.warning) html += `<br><br><small>${esc(data.warning)}</small>`;
    if (data.sources?.length) {
      html += `<br><br><strong>${lang==="rw"?"Amasoko:":lang==="fr"?"Sources :":"Sources:"}</strong><br>`;
      html += data.sources.slice(0,4).map(s=>`<a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.name)}</a>`).join("<br>");
    }
    addMessage(html,"assistant",true);
  } catch (err) {
    waiting.remove();
    addMessage(err.message || "Something went wrong.");
  } finally { $("#sendButton").disabled = false; $("#chatInput").focus(); }
}
function renderQuiz() {
  const card = $("#quizCard");
  if (!quiz.length) { card.textContent="Quiz unavailable."; return; }
  if (quizIndex >= quiz.length) {
    card.innerHTML = `<div class="quiz-progress">${translations[lang].quizDone}</div><h3 class="quiz-question">${translations[lang].score}: ${quizScore} / ${quiz.length}</h3><button class="button button-primary" id="restartQuiz">↻ ${lang==="rw"?"Ongera utangire":lang==="fr"?"Recommencer":"Try again"}</button>`;
    $("#restartQuiz").onclick=()=>{quizIndex=0;quizScore=0;quizAnswered=false;renderQuiz();};
    return;
  }
  const q=quiz[quizIndex];
  card.innerHTML=`<div class="quiz-progress">${translations[lang].question.toUpperCase()} ${quizIndex+1} / ${quiz.length}</div><h3 class="quiz-question">${esc(textFor(q.q))}</h3><div class="quiz-options">${q.options[lang].map((o,i)=>`<button class="quiz-option" data-answer="${i}">${String.fromCharCode(65+i)}. ${esc(o)}</button>`).join("")}</div><div id="quizFeedback" class="quiz-feedback"></div>`;
  card.querySelectorAll("[data-answer]").forEach(btn=>btn.onclick=()=>{
    if(quizAnswered)return;
    quizAnswered=true;
    const choice=Number(btn.dataset.answer);
    if(choice===q.answer){quizScore++;btn.classList.add("correct");$("#quizFeedback").textContent=translations[lang].correct+textFor(q.explain);}
    else{btn.classList.add("wrong");card.querySelector(`[data-answer="${q.answer}"]`).classList.add("correct");$("#quizFeedback").textContent=translations[lang].incorrect+textFor(q.explain);}
    const next=document.createElement("button");next.className="button button-primary quiz-next";next.textContent=quizIndex===quiz.length-1?translations[lang].finish:translations[lang].next;next.onclick=()=>{quizIndex++;quizAnswered=false;renderQuiz();};$("#quizFeedback").after(next);
  });
}
async function init() {
  $("#year").textContent=new Date().getFullYear();
  try {
    const res=await fetch("/api/history");
    const data=await res.json();
    topics=data.topics||[];quiz=data.quiz||[];sources=data.sources||[];
    renderTopics();renderTimeline();renderQuiz();renderSources();
  } catch(e) { $("#topicGrid").innerHTML='<div class="loading-card">Could not load history data. Please refresh the page.</div>'; }
}
$("#language").addEventListener("change",e=>{lang=e.target.value;applyLanguage();});
$("#searchInput").addEventListener("input",e=>renderTopics(e.target.value));
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();sendChat();});
$("#chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChat();}});
document.querySelectorAll("[data-question]").forEach(btn=>btn.addEventListener("click",()=>{sendChat(btn.dataset.question);document.querySelector("#assistant").scrollIntoView({behavior:"smooth"});}));
$("#modalAsk").addEventListener("click",()=>{if(currentTopic){const title=textFor(currentTopic.title);closeModal();$("#chatInput").value=lang==="rw"?`Mbwira birambuye kuri ${title}.`:lang==="fr"?`Expliquez-moi davantage : ${title}.`:`Tell me more about ${title}.`;document.querySelector("#assistant").scrollIntoView({behavior:"smooth"});$("#chatInput").focus();}});
document.querySelectorAll("[data-close]").forEach(el=>el.addEventListener("click",closeModal));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("#searchInput").focus();}});
$("#menuToggle").addEventListener("click",()=>$(".desktop-nav").classList.toggle("open"));
document.querySelectorAll(".desktop-nav a").forEach(a=>a.addEventListener("click",()=>$(".desktop-nav").classList.remove("open")));
init();
